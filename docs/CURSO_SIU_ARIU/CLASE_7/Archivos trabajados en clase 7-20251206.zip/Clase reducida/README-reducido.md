# MONITORING KUBERNETES

## 1. Monitoreo básico con metrics-server

### Instalar metrics-server
```bash
kubectl apply -f https://raw.githubusercontent.com/techiescamp/kubeadm-scripts/main/manifests/metrics-server.yaml
```

> Revisar manifiesto

Revisar recursos asociados al `metrics-server`
```bash
k ns kube-system
k get all | grep metrics-server
```

### Comandos básicos de monitoreo
```bash
# Ver métricas de nodos
kubectl top nodes

# Ver métricas de pods
kubectl top pods --all-namespaces

# Ver eventos del clúster
kubectl get events --all-namespaces --sort-by='.lastTimestamp' | tail -10
```

## 2. Stack completo de monitoreo

### Preparar repositorios Helm y crear namespace
```bash
# Agregar repositorios con versiones específicas
helm repo add prometheus-community https://prometheus-community.github.io/helm-charts
helm repo add grafana https://grafana.github.io/helm-charts
helm repo update

# Crear namespace
kubectl create ns monitor

# Verificar que existe el StorageClass nfs-client
kubectl get storageclass nfs-client
```

## 3. Instalar Prometheus + Grafana + AlertManager

### Usar la configuración completa preparada
```bash
# Usar el archivo de configuración ya preparado con versión específica
helm install monitor prometheus-community/kube-prometheus-stack --version 67.5.0 -n monitor -f monitor-values-completo.yaml
```

> **Nota**: El archivo `monitor-values-completo.yaml` contiene toda la configuración necesaria incluyendo:
> - Persistencia configurada con StorageClass nfs-client
> - Reglas de alerta por defecto + ejemplos personalizados
> - Configuración de AlertManager básica
> - Ingress para acceso a Grafana

## 4. Verificar instalación y acceder a Grafana

```bash
# Verificar pods
kubectl get pods -n monitor

# Verificar ingress
kubectl get ingress -n monitor

# Acceder a Grafana vía Ingress
# Usuario: admin
# Password: admin123
echo "Grafana disponible en: https://monitor.k8s.riu.edu.ar"

# Para pruebas locales, usar port-forward
kubectl port-forward svc/monitor-grafana 3000:80 -n monitor
# Acceder en: http://localhost:3000
```

## 5. Instalar Loki y Promtail para logs

### Instalar Loki y Promtail usando configuraciones preparadas
```bash
# Instalar Loki con configuración completa y versión específica
helm install loki grafana/loki --version 6.33.0 -n monitor -f loki-values-completo.yaml

# Instalar Promtail con configuración completa y versión específica
helm install promtail grafana/promtail --version 6.17.0 -n monitor -f promtail-values-completo.yaml
```

> **Nota**: Los archivos de configuración incluyen:
> - `loki-values-completo.yaml`: Configuración SingleBinary con persistencia nfs-client (ideal para laboratorio)
> - `promtail-values-completo.yaml`: Configuración simple para recolección de logs

## 6. Configurar Loki como datasource en Grafana

1. Acceder a Grafana
2. Ir a **Connections** > **Data sources** > **Add data source**
3. Seleccionar **Loki**
4. URL: `http://loki-gateway:80`
5. Guardar y probar

## 6.1. Explorar AlertManager y reglas de alerta

### Alertas por defecto
El stack viene con alertas predefinidas para:
- **Kubernetes**: Pods no saludables, nodos no listos, etc.
- **Prometheus**: Targets caídos, almacenamiento lleno, etc.
- **Node Exporter**: CPU alto, memoria baja, disco lleno, etc.
- **Grafana**: Instancia caída

### Alertas personalizadas (ejemplos incluidos)
El archivo de configuración incluye 2 ejemplos de alertas personalizadas:
1. **HighApplicationLatency**: Detecta latencia alta en aplicaciones
2. **NamespaceCpuUsageHigh**: Monitrea uso de CPU por namespace

```bash
# Ver alertas activas en Grafana
# Ir a: Alerting > Alert rules

# Ver AlertManager directamente
kubectl port-forward svc/monitor-kube-prometheus-st-alertmanager 9093:9093 -n monitor
# Acceder en: http://localhost:9093
```

## 7. Importar dashboards y explorar métricas

### Dashboards recomendados para importar en Grafana
```bash
# 1. Kubernetes cluster monitoring: ID 315
# 2. Node Exporter Full: ID 1860
# 3. Kubernetes Deployment Statefulset Daemonset metrics: ID 8588
```

### Queries útiles para explorar

#### En Prometheus (Explore):
```promql
# Servicios activos
up

# Memoria disponible por nodo
node_memory_MemAvailable_bytes / 1024 / 1024 / 1024

# Estado de pods
kube_pod_status_phase

# Uso de CPU por contenedor
rate(container_cpu_usage_seconds_total[5m])

# Pods en crash loop
increase(kube_pod_container_status_restarts_total[1m]) > 0
```

#### En Loki (Explore):
```logql
# Todos los logs del namespace default
{namespace="default"}

# Logs con errores de cualquier pod
{pod=~".*"} |= "error"

# Logs de un pod específico
{pod="prometheus-server-xxx"}

# Logs con nivel de log específico
{namespace="monitor"} |= "level=warn"
```

## 8. Verificación final y pruebas

```bash
# Verificar todos los pods están corriendo
kubectl get pods -n monitor

# Verificar servicios y sus puertos
kubectl get svc -n monitor

# Verificar PVCs creados
kubectl get pvc -n monitor

# Probar conectividad a servicios principales
echo "Grafana: https://monitor.k8s.riu.edu.ar (admin/admin123)"
echo "Loki Gateway: Puerto interno 80"

# Opcional: Port-forward para AlertManager
kubectl port-forward svc/monitor-kube-prometheus-st-alertmanager 9093:9093 -n monitor &
echo "AlertManager: http://localhost:9093"
```

### Generar algunas alertas de prueba
```bash
# Crear un pod que consuma recursos para disparar alertas
kubectl run stress-test --image=polinux/stress --rm -it --restart=Never -- stress --cpu 2 --timeout 60s

# Crear un pod que falle para probar alertas de crash loop
kubectl run failing-pod --image=busybox --restart=Always -- sh -c "exit 1"
```

## 9. Puntos clave de la clase

### ¿Qué hemos instalado?
- **Metrics Server**: Para métricas básicas de recursos (CPU, memoria)
- **Prometheus**: Para recolección y almacenamiento de métricas
- **Grafana**: Para visualización de métricas y dashboards
- **AlertManager**: Para gestión y enrutado de alertas
- **Loki**: Para agregación y consulta de logs
- **Promtail**: Para recolección de logs desde los nodos

### Arquitectura del stack de monitoreo
```
Aplicaciones → Prometheus (métricas) → Grafana (visualización)
                    ↓
               AlertManager (alertas)

Aplicaciones → Promtail (logs) → Loki → Grafana (consulta logs)
```

### URLs de acceso importantes
- Grafana: `https://monitor.k8s.edu.ar` (admin/admin123)
- Loki Gateway: Puerto interno 80 (acceso desde Grafana)
- AlertManager: Port-forward a puerto 9093

## 10. Limpieza (opcional)

```bash

# Limpiar pods de prueba
kubectl delete pod stress-test failing-pod --ignore-not-found

# Desinstalar aplicaciones Helm (CUIDADO: esto borra todos los datos)
helm uninstall monitor promtail loki -n monitor

# Eliminar CRDs creados por kube-prometheus-stack (no se eliminan automáticamente)
kubectl delete crd alertmanagerconfigs.monitoring.coreos.com
kubectl delete crd alertmanagers.monitoring.coreos.com
kubectl delete crd podmonitors.monitoring.coreos.com
kubectl delete crd probes.monitoring.coreos.com
kubectl delete crd prometheusagents.monitoring.coreos.com
kubectl delete crd prometheuses.monitoring.coreos.com
kubectl delete crd prometheusrules.monitoring.coreos.com
kubectl delete crd scrapeconfigs.monitoring.coreos.com
kubectl delete crd servicemonitors.monitoring.coreos.com
kubectl delete crd thanosrulers.monitoring.coreos.com

# Eliminar PVCs (datos persistentes)
kubectl delete pvc -n monitor --all

# Eliminar namespace completo
kubectl delete namespace monitor

# Nota: No eliminamos nfs-client ya que es el StorageClass del cluster
```

## Recursos adicionales

- [Documentación oficial Prometheus](https://prometheus.io/docs/)
- [Dashboards Grafana](https://grafana.com/grafana/dashboards/)
- [Awesome Prometheus Alerts](https://samber.github.io/awesome-prometheus-alerts/)
- [LogQL Documentation](https://grafana.com/docs/loki/latest/logql/)