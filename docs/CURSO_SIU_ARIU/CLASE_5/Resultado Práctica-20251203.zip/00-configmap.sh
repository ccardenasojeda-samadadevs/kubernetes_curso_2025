kubectl create configmap phpini --from-file=php.ini 
