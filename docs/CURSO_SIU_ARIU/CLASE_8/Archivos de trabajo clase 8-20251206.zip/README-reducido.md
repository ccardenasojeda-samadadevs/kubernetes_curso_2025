# ACTUALIZACIÓN KUBERNETES 1.33 → 1.34

## Objetivo
Actualizar un cluster Kubernetes de la versión 1.33.x a 1.34.2 (última disponible) dividido en dos comisiones:
- **Mañana**: Actualización dentro de 1.33 (1.33.x → 1.33.6)  
- **Tarde**: Salto de versión mayor (1.33.6 → 1.34.2)

## 1. Información de versiones actuales

### Versiones disponibles (Noviembre 2025)
- **Kubernetes 1.33**: Última 1.33.6 (End of Life: 2026-06-28)
- **Kubernetes 1.34**: Última 1.34.2 (End of Life: 2026-10-27)

### Verificar versión actual
```bash
kubectl version
kubeadm version
```

## 2. Pre-requisitos y preparación

### Backup y seguridad
```bash
# Verificar etcd está funcionando
kubectl get nodes
kubectl get pods -A | grep -E "(etcd|api-server)"

# Backup manual de configuraciones críticas
cp -r /etc/kubernetes /etc/kubernetes.backup.$(date +%Y%m%d)
```

## 3. COMISIÓN MAÑANA: Actualización 1.33.x → 1.33.6

### 3.1. Preparar imágenes (adelantar trabajo)
```bash
kubeadm config images pull --kubernetes-version v1.33.6
```

### 3.2. Control Plane - Primer nodo

```bash
# Drenar nodo
kubectl drain <control-plane-node> --ignore-daemonsets --delete-emptydir-data

# Actualizar repositorio (si es necesario)
curl -fsSL https://pkgs.k8s.io/core:/stable:/v1.33/deb/Release.key | sudo gpg --dearmor -o /etc/apt/keyrings/kubernetes-apt-keyring.gpg
apt update

# Verificar versiones disponibles
apt-cache madison kubeadm

# Actualizar kubeadm
apt-mark unhold kubeadm && \
apt-get update && apt-get install -y kubeadm='1.33.6-1.1' && \
apt-mark hold kubeadm

# Verificar y aplicar actualización
kubeadm upgrade plan
kubeadm upgrade apply v1.33.6

# Actualizar kubelet y kubectl
apt-mark unhold kubelet kubectl && \
apt-get update && apt-get install -y kubelet='1.33.6-1.1' kubectl='1.33.6-1.1' && \
apt-mark hold kubelet kubectl

# Reiniciar servicios
systemctl daemon-reload
systemctl restart kubelet

# Liberar nodo
kubectl uncordon <control-plane-node>
```

### 3.3. Control Planes adicionales
```bash
# Drenar nodo
kubectl drain <control-plane-node> --ignore-daemonsets --delete-emptydir-data

# Actualizar repositorio (si es necesario)
curl -fsSL https://pkgs.k8s.io/core:/stable:/v1.33/deb/Release.key | sudo gpg --dearmor -o /etc/apt/keyrings/kubernetes-apt-keyring.gpg
apt update

# Verificar versiones disponibles
apt-cache madison kubeadm

# Actualizar kubeadm
apt-mark unhold kubeadm && \
apt-get update && apt-get install -y kubeadm='1.33.6-1.1' && \
apt-mark hold kubeadm

# Para nodos adicionales usar 'node' en lugar de 'apply'
kubeadm upgrade node

# Actualizar kubelet y kubectl
apt-mark unhold kubelet kubectl && \
apt-get update && apt-get install -y kubelet='1.33.6-1.1' kubectl='1.33.6-1.1' && \
apt-mark hold kubelet kubectl

# Reiniciar servicios
systemctl daemon-reload
systemctl restart kubelet

# Liberar nodo
kubectl uncordon <control-plane-node>
```

### 3.4. Workers
```bash
# En cada worker (uno por vez)
kubectl drain <worker-node> --ignore-daemonsets --delete-emptydir-data

# Actualizar kubeadm
apt-mark unhold kubeadm && \
apt-get update && apt-get install -y kubeadm='1.33.6-1.1' && \
apt-mark hold kubeadm

kubeadm upgrade node

# Actualizar kubelet y kubectl
apt-mark unhold kubelet kubectl && \
apt-get update && apt-get install -y kubelet='1.33.6-1.1' kubectl='1.33.6-1.1' && \
apt-mark hold kubelet kubectl

systemctl daemon-reload
systemctl restart kubelet

kubectl uncordon <worker-node>
```

### 3.5. Verificación
```bash
kubectl get nodes
kubectl version --short
```

## 4. COMISIÓN TARDE: Salto mayor 1.33.6 → 1.34.2

### 4.1. Preparar imágenes
```bash
kubeadm config images pull --kubernetes-version v1.34.2
```

### 4.2. Actualizar repositorio para 1.34
```bash
# Cambiar a repositorio 1.34
curl -fsSL https://pkgs.k8s.io/core:/stable:/v1.34/deb/Release.key | sudo gpg --dearmor -o /etc/apt/keyrings/kubernetes-apt-keyring.gpg

# Actualizar sources.list si es necesario
echo "deb [signed-by=/etc/apt/keyrings/kubernetes-apt-keyring.gpg] https://pkgs.k8s.io/core:/stable:/v1.34/deb/ /" | sudo tee /etc/apt/sources.list.d/kubernetes.list

apt update
apt-cache madison kubeadm
```

### 4.3. Control Plane - Primer nodo
```bash
# Drenar nodo
kubectl drain <control-plane-node> --ignore-daemonsets --delete-emptydir-data

# Actualizar kubeadm
apt-mark unhold kubeadm && \
apt-get update && apt-get install -y kubeadm='1.34.2-1.1' && \
apt-mark hold kubeadm

# Plan y aplicar actualización mayor
kubeadm upgrade plan
kubeadm upgrade apply v1.34.2

# ⚠️ ACTUALIZAR CNI (SOLO en este primer control plane)
# Verificar si necesita actualización para compatibilidad con K8s 1.34
kubectl apply -f https://raw.githubusercontent.com/projectcalico/calico/v3.30.2/manifests/calico.yaml

# Verificar que los pods de Calico se actualicen correctamente
kubectl get pods -n kube-system | grep calico

# Actualizar kubelet y kubectl
apt-mark unhold kubelet kubectl && \
apt-get update && apt-get install -y kubelet='1.34.2-1.1' kubectl='1.34.2-1.1' && \
apt-mark hold kubelet kubectl

systemctl daemon-reload
systemctl restart kubelet

kubectl uncordon <control-plane-node>
```

### 4.4. Control Planes adicionales (1.34.2)
```bash
# Drenar nodo
kubectl drain <control-plane-node-2> --ignore-daemonsets --delete-emptydir-data

# Actualizar kubeadm
apt-mark unhold kubeadm && \
apt-get update && apt-get install -y kubeadm='1.34.2-1.1' && \
apt-mark hold kubeadm

# Para nodos adicionales usar 'node' en lugar de 'apply'
kubeadm upgrade node

# Actualizar kubelet y kubectl
apt-mark unhold kubelet kubectl && \
apt-get update && apt-get install -y kubelet='1.34.2-1.1' kubectl='1.34.2-1.1' && \
apt-mark hold kubelet kubectl

systemctl daemon-reload
systemctl restart kubelet

kubectl uncordon <control-plane-node-2>
```

### 4.5. Workers (1.34.2)
```bash
# En cada worker (uno por vez)
kubectl drain <worker-node> --ignore-daemonsets --delete-emptydir-data

# Actualizar repositorio para 1.34
curl -fsSL https://pkgs.k8s.io/core:/stable:/v1.34/deb/Release.key | sudo gpg --dearmor -o /etc/apt/keyrings/kubernetes-apt-keyring.gpg
echo "deb [signed-by=/etc/apt/keyrings/kubernetes-apt-keyring.gpg] https://pkgs.k8s.io/core:/stable:/v1.34/deb/ /" | sudo tee /etc/apt/sources.list.d/kubernetes.list
apt update

# Actualizar kubeadm
apt-mark unhold kubeadm && \
apt-get update && apt-get install -y kubeadm='1.34.2-1.1' && \
apt-mark hold kubeadm

kubeadm upgrade node

# Actualizar kubelet y kubectl
apt-mark unhold kubelet kubectl && \
apt-get update && apt-get install -y kubelet='1.34.2-1.1' kubectl='1.34.2-1.1' && \
apt-mark hold kubelet kubectl

systemctl daemon-reload
systemctl restart kubelet

kubectl uncordon <worker-node>
```



## 5. Actualizaciones de software adicional

Basado en tu documentación, también actualizas regularmente:

### 5.1. Componentes principales que actualizas (post-K8s)
- **Ingress NGINX** → Usar manifiestos personalizados  
- **Cert-Manager** → Con CRDs  
- **MetalLB** → Aplicar manifiestos + quitar etiquetas  
- **Vault** → Actualizar values (Helm)  
- **Vault Operator** → Helm upgrade  
- **Capsule** → Con values personalizado  
- **Velero** → Backup/restore  
- **Prometheus Stack** → Con CRDs upgrade  
- **Loki** → Helm upgrade  

> **Nota**: Estos componentes se actualizan DESPUÉS de completar totalmente la actualización de Kubernetes y verificar que el cluster esté estable.

### 5.2. Ejemplo rápido - Monitor Stack
```bash
# Solo como ejemplo de una actualización típica post-kubernetes
helm repo update
helm upgrade --install monitor prometheus-community/kube-prometheus-stack \
  -n monitor --version 75.13.0 \
  --set crds.upgradeJob.enabled=true \
  -f values-personalizados.yaml
```

## 6. Verificación final

```bash
# Verificar cluster
kubectl get nodes
kubectl get pods -A | grep -v Running
kubectl version --short

# Verificar componentes críticos
kubectl get pods -n kube-system
kubectl get pods -n ingress-nginx
kubectl get pods -n cert-manager

# Probar funcionalidad básica
kubectl run test-pod --image=nginx --rm -it --restart=Never -- curl -I httpbin.org/status/200
```
