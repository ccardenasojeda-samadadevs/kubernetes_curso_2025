# CLASE 8

## Update k8s version

### Encontrar la última versión disponible a actualizar
```bash
apt update
apt-cache madison kubeadm
```

### Actualización del primer Control Plane

#### Descargar paquetes actualizados
```bash
apt-mark unhold kubeadm && \
apt-get update && apt-get install -y kubeadm=1.27.4-00 && \
apt-mark hold kubeadm
```

#### Verifica que la descarga funcione y Plan de actualización
```bash
kubeadm version
kubeadm upgrade plan
```

#### Según indique en el plan, hay que realizar el upgrade correspondiente

Si es necesario realizar downgrade de kubeadm
```bash
apt-mark unhold kubeadm && apt-get update && apt-get install -y kubeadm=1.26.9-00 --allow-downgrades && apt-mark hold kubeadm
```

Realizar upgrade del control plane
```bash
kubeadm upgrade apply v1.26.9
```

### Revisar y Actualizar el controlador de Red (Calico)

### Para el resto de los nodos del control plane ejecutar:

#### Actualizar version de kubeadm
```bash
apt update
apt-mark unhold kubeadm && \
apt-get update && apt-get install -y kubeadm=1.26.9-00 && \
apt-mark hold kubeadm
```

#### Upgrade
```bash
kubeadm upgrade node
```

#### Actualizar Kubelet y Kubectl para cada nodo control plane
```bash
kubectl drain <cada-control-plane> --ignore-daemonsets
```

#### Upgrade kubelet
```bash
apt-mark unhold kubelet kubectl && \
apt-get update && apt-get install -y kubelet=1.26.9-00 kubectl=1.26.9-00 && \
apt-mark hold kubelet kubectl
```

#### reload y uncordon

```bash
systemctl daemon-reload
systemctl restart kubelet
```

```bash
kubectl uncordon <nodo>
```

###	Actualizar Worker
```bash
apt-mark unhold kubeadm && \
apt-get update && apt-get install -y kubeadm=1.26.9-00 && \
apt-mark hold kubeadm
```

```bash
kubeadm upgrade node
```

```bash
kubectl drain <node-to-drain> --delete-local-data --ignore-daemonsets
```

```bash
apt-mark unhold kubelet kubectl && \
apt-get update && apt-get install -y kubelet=1.26.9-00 kubectl=1.26.9-00 && \
apt-mark hold kubelet kubectl
```

```bash
systemctl daemon-reload
systemctl restart kubelet
```

```bash
kubectl uncordon <node-to-uncordon>
```

