# MONITORING KUBERNETES

## Monitoreo básico

### Instalar metrics-server
```bash
kubectl apply -f https://raw.githubusercontent.com/techiescamp/kubeadm-scripts/main/manifests/metrics-server.yaml
```

> Revisar manifiesto

Revisar recursos asociados al `metrics-server`
```bash
k ns kube-system
k get all | grep metrics-server
```

### Comandos básicos de monitoreo
```bash
k top nodes
```
```bash
k describe node ed-k8s-001
```
> Comparar los recursos usados por el nodo (top node) con los request/limits (describe node)

```bash
k top pod 
```

> Ejecutar varias veces para ver que no se actualiza constantemente 


### Ver logs de un conteiner específico de un pod
```bash
k ns longhorn-system
k logs longhorn-csi-plugin-<ID>
k logs longhorn-csi-plugin-<ID> -c longhorn-liveness-probe
```

### Ver eventos del clúster
```bash
kubectl get events --all-namespaces
```

### Ver todos los recursos 
```bash
k get-all -n longhorn-system
```
## Prometheus - Grafana

Fuente: 

- Git: https://prometheus-community.github.io/helm-charts
- Artifac hub: https://artifacthub.io/packages/helm/prometheus-community/kube-prometheus-stack
- Alert rules: https://awesome-prometheus-alerts.grep.to/rules.html#kubernetes

### Agregar prometheus-community repo de helm

```bash
helm repo add prometheus-community https://prometheus-community.github.io/helm-charts
helm repo update
```

### Crear namespace para monitor

```bash
kubectl create ns monitor
```

### Instalar el stack de prom-grafana para kubernetes desde el chart de helm

```bash
helm show values prometheus-community/kube-prometheus-stack >> values.yaml
helm install monitor prometheus-community/kube-prometheus-stack -n monitor -f values.yaml
```

### Volumenes

#### Crear SC longhorn con una réplica
```bash
k apply -f 01-sc-longhorn.yaml
```

#### Crear volumen para grafana

```bash
helm upgrade --reuse-values -f 02-grafana-volumen.yaml monitor prometheus-community/kube-prometheus-stack -n monitor
```

#### Crear volumen para prometheus

```bash
helm upgrade --reuse-values -f 03-prometheus-volumen.yaml monitor prometheus-community/kube-prometheus-stack -n monitor
```

### Ingress

#### Crear ingress para grafana

```bash
kubectl apply -f 04-grafana-ingress.yaml
```

### Explorar Grafana
Ingresar con las siguientes credenciales:

-   Username: admin
-   Password: prom-operator

#### Data Source:
Connections -> Data sources -> Prometheus

#### Plugins
Administration -> Plugins

#### Consultas - Queries
Explore
> container_memory_usage_bytes 
> :node_memory_MemAvailable_bytes:sum

#### Panel - Transformaciones
Dashboards -> Node Exporter / Nodes -> Disk Space Usage


## Explorar dashboards

### Importar dashboard 11000
https://grafana.com/grafana/dashboards/

Dashboard > "+" > Import Dasboard > 11000

### Importar dashboard de IT desde json
Dashboard > "+" > Import Dasboard > 05-dashboard-it.json

### Agregar job para recolección de métricas externas a prometheus

```bash
helm upgrade --reuse-values -f 06-prometheus-job.yaml monitor prometheus-community/kube-prometheus-stack -n monitor
```

### Exponer Prometheus
```bash
kubectl port-forward svc/monitor-kube-prometheus-st-prometheus 9090:9090 -n monitor
```
ingresar a: http://127.0.0.1:9090

### Revisar en `status > target` que esté el uptime configurado

### Importar dashboard de UPTIME desde json
Dashboard > "+" > Import Dasboard > 06-dashboard-uptime.json

## AlertManager y Alert Rules

### Mostrar alertas desde Grafana
Alerting > Alert rules

### Quitar alertas por defecto

Dos formas:

1. Eliminando rules
```bash
k get prometheusrules.monitoring.coreos.com
k delete prometheusrules.monitoring.coreos.com monitor-kube-prometheus-st-config-reloaders
```

2. Editando Values de Promeheus y volviendo a aplicar helm
```bash
helm upgrade --reuse-values -f 08-prometheus-rules-false.yaml monitor prometheus-community/kube-prometheus-stack -n monitor
```

### Revisar alertas desde url 
https://samber.github.io/awesome-prometheus-alerts/
https://samber.github.io/awesome-prometheus-alerts/rules.html#kubernetes
https://samber.github.io/awesome-prometheus-alerts/rules#host-and-hardware

```bash
nano 09-alert-rules.yaml
helm upgrade --reuse-values -f 09-alert-rules.yaml monitor prometheus-community/kube-prometheus-stack -n monitor
```

## Promtail - Loki

Fuente: https://github.com/digitalocean/Kubernetes-Starter-Kit-Developers/blob/main/04-setup-observability/loki-stack.md

### Mostrar configuracion en `10-loki-stack-values.yaml`

### Desplegar promtail y loki

```bash
helm install loki grafana/loki-stack --namespace=monitor -f "10-loki-stack-values.yaml" 
```

### Agregar datasource en grafana: http://loki.monitor:3100.

### Importar dashboard 13639

### Importar dashboard de loki `11-dashboard-loki.json`

## Uninstall helm chart

```bash
helm uninstall monitor
kubectl delete crd alertmanagerconfigs.monitoring.coreos.com
kubectl delete crd alertmanagers.monitoring.coreos.com
kubectl delete crd podmonitors.monitoring.coreos.com
kubectl delete crd probes.monitoring.coreos.com
kubectl delete crd prometheuses.monitoring.coreos.com
kubectl delete crd prometheusrules.monitoring.coreos.com
kubectl delete crd servicemonitors.monitoring.coreos.com
kubectl delete crd thanosrulers.monitoring.coreos.com
```